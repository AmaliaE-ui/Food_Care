package ispw.food_care.model;

import java.sql.SQLException;
import ispw.food_care.bean.PatientBean;
import ispw.food_care.dao.PatientDAO;
import ispw.food_care.dao.UserDAO;


public class PatientModel {

    public void registerPatient(String name, String surname, String phone, String username, String email, String password, String birthDate, String gender) throws SQLException {
        PatientBean bean = new PatientBean();
        bean.setName(name);
        bean.setSurname(surname);
        bean.setPhone(phone);
        bean.setUsername(username);
        bean.setEmail(email);
        bean.setPassword(password);
        bean.setBirthDate(birthDate);
        bean.setGender(gender);

        new UserDAO().saveUser(bean);       // salva nella tabella user
        new PatientDAO().savePatient(bean); // salva nella tabella patient
    }



}
